#ifndef NOTEMANAGER_H
#define NOTEMANAGER_H

#include <vector>
#include <iostream>
#include "Note.h"
#include "Subject.h"

class NoteManager : public Subject {
private:
    std::vector<Note*> notes;

public:
    void addNote(Note* note) {
        notes.push_back(note);
        notify(note);
    }

    void deleteNote(const std::string& title) {
        for (auto it = notes.begin(); it != notes.end(); ++it) {
            if ((*it)->getTitle() == title && !(*it)->getLocked()) {
                delete *it;
                notes.erase(it);
                std::cout << "Note supprimée.\n";
                notify();
                return;
            }
        }
        std::cout << "Note introuvable ou bloquée.\n";
    }

    Note* getNote(const std::string& title) {
        for (auto* note : notes) {
            if (note->getTitle() == title) return note;
        }
        return nullptr;
    }

    void afficherToutesLesNotes() const {
        if (notes.empty()) {
            std::cout << "Aucune note.\n";
            return;
        }
        for (const auto* note : notes) {
            std::cout << "- " << note->getTitle()
                      << " (" << note->getCollectionName() << ")"
                      << (note->getLocked() ? " [bloquée]" : "")
                      << (note->getIsImportant() ? " [importante]" : "")
                      << "\n";
        }
    }

    void afficherNotesImportantes() const {
        bool found = false;
        for (const auto* note : notes) {
            if (note->getIsImportant()) {
                found = true;
                std::cout << "- " << note->getTitle() << ": " << note->getContent() << "\n";
            }
        }
        if (!found) std::cout << "Aucune note importante.\n";
    }

    ~NoteManager() {
        for (auto* note : notes)
            delete note;
    }
};

#endif // NOTEMANAGER_H

