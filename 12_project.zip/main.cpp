#include <iostream>
#include "NoteManager.h"
#include "Collection.h"

int main() {
    NoteManager manager;

    // Création de quelques notes
    Note* note1 = new Note("Projet C++", "Réaliser le projet final", "Université", false);
    Note* note2 = new Note("Courses", "Acheter du lait et du pain", "Perso", true);

    // Ajout des notes
    manager.addNote(note1);
    manager.addNote(note2);

    // Affichage de toutes les notes
    std::cout << "===== Toutes les notes =====" << std::endl;
    manager.afficherToutesLesNotes();

    // Verrouillage de la note 1
    note1->lock();

    // Essai de modification (devrait échouer si bloquée)
    if (!note1->getLocked()) {
        note1->setContent("Mise à jour du contenu");
    } else {
        std::cout << "[INFO] Note verrouillée : modification refusée." << std::endl;
    }

    // Déverrouillage
    note1->unlock();
    note1->setContent("Mise à jour du contenu après déverrouillage");

    // Marquer comme importante
    note2->setImportant(true);

    // Affichage des notes importantes
    std::cout << "\n===== Notes importantes =====" << std::endl;
    manager.afficherNotesImportantes();

    // Suppression d'une note
    manager.deleteNote("Courses");

    // Affichage après suppression
    std::cout << "\n===== Après suppression =====" << std::endl;
    manager.afficherToutesLesNotes();

    return 0;
}
