#include <gtest/gtest.h>
#include "Note.h"
#include "Collection.h"

TEST(CollectionTest, AddAndCountNotes) {
    Note* n1 = new Note("A", "Text A", "Travail");
    Note* n2 = new Note("B", "Text B", "Travail");

    Collection col("Travail");
    col.addNote(n1);
    col.addNote(n2);

    EXPECT_EQ(col.getNoteCount(), 2);

    delete n1;
    delete n2;
}

TEST(CollectionTest, RemoveUnlockedNote) {
    Note* n1 = new Note("A", "Text A", "Perso");
    Collection col("Perso");
    col.addNote(n1);
    col.removeNote("A");

    EXPECT_EQ(col.getNoteCount(), 0);
    delete n1;
}

TEST(CollectionTest, BlockedNoteNotRemoved) {
    Note* n1 = new Note("A", "Text A", "Perso");
    n1->lock();

    Collection col("Perso");
    col.addNote(n1);
    col.removeNote("A");

    EXPECT_EQ(col.getNoteCount(), 1);
    delete n1;
}
