#include <gtest/gtest.h>
#include "Note.h"

TEST(NoteTest, Creation) {
    Note note("Titre", "Contenu", "Travail", false);

    EXPECT_EQ(note.getTitle(), "Titre");
    EXPECT_EQ(note.getContent(), "Contenu");
    EXPECT_EQ(note.getCollectionName(), "Travail");
    EXPECT_FALSE(note.getLocked());
    EXPECT_FALSE(note.getIsImportant());
}

TEST(NoteTest, LockAndModify) {
    Note note("Titre", "Contenu", "Perso");

    note.lock();
    note.setTitle("Nouveau Titre");
    note.setContent("Nouveau contenu");
    note.setCollectionName("Autre");

    EXPECT_EQ(note.getTitle(), "Titre");
    EXPECT_EQ(note.getContent(), "Contenu");
    EXPECT_EQ(note.getCollectionName(), "Perso");
}

TEST(NoteTest, UnlockAndModify) {
    Note note("Titre", "Contenu", "Perso");
    note.lock();
    note.unlock();

    note.setTitle("Titre 2");
    note.setContent("Contenu 2");
    note.setCollectionName("Test");

    EXPECT_EQ(note.getTitle(), "Titre 2");
    EXPECT_EQ(note.getContent(), "Contenu 2");
    EXPECT_EQ(note.getCollectionName(), "Test");
}

TEST(NoteTest, ImportantFlag) {
    Note note("Titre", "Contenu", "Travail");

    EXPECT_FALSE(note.getIsImportant());
    note.setImportant(true);
    EXPECT_TRUE(note.getIsImportant());
}

