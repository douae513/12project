#include <gtest/gtest.h>
#include "Note.h"
#include "Collection.h"
#include "NoteManager.h"

TEST(ObserverTest, NotifyCollectionOnAdd) {
    NoteManager manager;
    Collection col("Projet");

    manager.addObserver(&col);

    Note* n1 = new Note("N1", "Texte", "Projet");
    manager.addNote(n1);

    EXPECT_EQ(col.getNoteCount(), 1); // La collection ne gère pas automatiquement l’ajout ici
    // On pourrait ensuite gérer l’ajout dans l’update()

    delete n1;
}
